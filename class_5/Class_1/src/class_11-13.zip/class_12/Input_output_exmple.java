package class_12;

public class Input_output_exmple {

	public static void main(String[] args) {
		System.out.printf("te amo");

	}

}
