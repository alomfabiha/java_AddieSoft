package quiz_1;

import java.util.Scanner;

public class Ans_3 {

	public static void main(String[] args) {
	int x = 0;

		if(x%2==0)
		{ 
			for (int i=0;i<=100;i++) {
			
			System.out.println("The Even number between 1 to 100 :)" +i);
			}
	
		}
		else 
		{
			for (int i=0;i<=100;i++) {
				
				System.out.println("The Odd number between 1 to 100 :)" +i);
				}
			
		
		}

	}

}
