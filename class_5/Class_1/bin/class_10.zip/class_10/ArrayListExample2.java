package class_10;

public class ArrayListExample2 {

	public static void main(String[] args) {
	double x=4.4;
	System.out.println(Math.abs(x));
	System.out.println(Math.ceil(x));
	System.out.println(Math.floor(x));
	System.out.println(Math.round(x));
	System.out.println(Math.random()+10);
	System.out.println(Math.sqrt(x));
	}

}
