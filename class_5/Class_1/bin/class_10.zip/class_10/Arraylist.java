package class_10;

import java.util.ArrayList;

public class Arraylist {

	public static void main(String[] args) {
		ArrayList<String> li=new ArrayList<String>();
	}

}
