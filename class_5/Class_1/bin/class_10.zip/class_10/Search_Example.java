package class_10;

public class Search_Example {

	public static void main(String[] args) {

		
		
		
	}

}
