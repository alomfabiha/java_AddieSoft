package Class_5;

public class Multi_Array {

	public static void main(String[] args) {
		//int [][ a= new int [2][3];
		int [][] a={{1,2,3},{2,3,4},{3,4,5}};
	for(int i=0; i<a.length;i++)
	{
		for(int j=0; j<a.length;j++) {
			System.out.print(a[i][j]+"      ");
		}
		System.out.println("");
	}
	
	}
	

}
