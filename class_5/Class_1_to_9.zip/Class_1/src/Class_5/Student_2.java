package Class_5;

public class Student_2 {
	 String name;
	 int age;
	Student_2(String name,int age){
	 this.name=name;
	 this.age=age;
	
	}

}
