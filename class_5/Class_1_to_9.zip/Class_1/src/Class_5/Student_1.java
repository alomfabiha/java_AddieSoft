package Class_5;

public class Student_1 {

	
	private String name;
	private int age;
	Student_1(String name,int age){
	 this.name=name;
	 this.age=age;
	
	}
	//Set method
	public void setName(String name) {
	this.name=name;
	}
	public void setAge(int age) {
	this.age=age;
	}
	//Get method
	String getName() {
	return name;
	}
	int getAge() {
		return age;
		}
	}
	
	


