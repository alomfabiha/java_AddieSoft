package Class_5;

public class Array_1 {

	public static void main(String[] args) {
		int a[]= new int[10];
		for (int i = 1; i<=10;i++)
		{
			if ( i<10) 
			{
			System.out.print(i +" , ");
			}
			else
			{
				System.out.print(i );
			}
		}
	}

}
