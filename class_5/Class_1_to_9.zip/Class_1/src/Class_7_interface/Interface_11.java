package Class_7_interface;

public interface Interface_11 {

	int value_1(int a,int b);
	void value_2();
	String value_3(String name , String roll);
	double value_4(double a , double b);
}
