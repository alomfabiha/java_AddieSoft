package Class_7_interface;

public class Interface_1 {

	public static void main(String[] args) {
		Interface_12 obj=new Interface_12();
		System.out.println(obj.value_1(5, 4));
		obj.value_2();
		System.out.println(obj.value_3("Niaz","5"))  ;
		System.out.println(obj.value_4(3.4 ,3));
		
	}

}
