package nested_innerClass_Class_9;

public class InnerMain_2 {

	public static void main(String[] args) {
		OuterClass21 obj=new OuterClass21();
		OuterClass21.InnerClass22 obj2=obj.new InnerClass22();
		obj2.display();

	}

}
