package class_6_Inheritance;

public class Main_1 extends SubClass_1{

	public static void main(String[] args) {
	Main_1 obj=new Main_1();
	obj.Comment_1();
	obj.First();

	}

}
