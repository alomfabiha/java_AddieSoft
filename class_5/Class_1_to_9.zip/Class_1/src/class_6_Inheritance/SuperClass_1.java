package class_6_Inheritance;

public class SuperClass_1  {
int a=10;
int b=6;
int sum=a+b;
	void First() {
	System.out.println("Sum = "+sum);
	}
}
	


