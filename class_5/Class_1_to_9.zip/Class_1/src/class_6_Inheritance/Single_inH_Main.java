package class_6_Inheritance;

public class Single_inH_Main {

	public static void main(String[] args) {
		Single_inH_2 obj=new Single_inH_2();
		obj.Comment_1();
		obj.First();

		}
	}


