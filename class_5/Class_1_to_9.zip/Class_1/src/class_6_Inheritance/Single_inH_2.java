package class_6_Inheritance;

public class Single_inH_2 extends Single_inH_1 {
	int min=a-b;
	void Comment_1()
	{
		System.out.println("min = "+min);
	}

}
