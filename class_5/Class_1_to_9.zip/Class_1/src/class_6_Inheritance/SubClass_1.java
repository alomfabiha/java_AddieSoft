package class_6_Inheritance;

public class SubClass_1 extends SuperClass_1{

	int min=a-b;
	void Comment_1()
	{
		System.out.println("min = "+min);
	}
}
