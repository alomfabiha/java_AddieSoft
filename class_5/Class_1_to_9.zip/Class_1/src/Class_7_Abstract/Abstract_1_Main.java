package Class_7_Abstract;

public class Abstract_1_Main {

	public static void main(String[] args) {
		Abstract_1 obj=new Abstract_11();
		int sum=obj.Calculation();
		System.out.println(sum);
		Abstract_12  obj_2=new Abstract_12();
		System.out.println(obj_2.Calculation());
	}

}
