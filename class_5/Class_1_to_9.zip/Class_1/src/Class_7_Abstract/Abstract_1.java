package Class_7_Abstract;

public abstract class Abstract_1 {

	int a=10;
	int b=5;
	abstract int Calculation();
	
}
