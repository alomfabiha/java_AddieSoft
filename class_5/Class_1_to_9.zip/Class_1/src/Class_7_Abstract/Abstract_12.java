package Class_7_Abstract;

public class Abstract_12 extends Abstract_1 {
	int Calculation(){
		int min=a-b;
		return min;
}
}
