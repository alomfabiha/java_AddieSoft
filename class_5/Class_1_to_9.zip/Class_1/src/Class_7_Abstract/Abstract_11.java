package Class_7_Abstract;

public class Abstract_11 extends Abstract_1{
	int Calculation(){
		int sum=a+b;
		return sum;
	}

}
