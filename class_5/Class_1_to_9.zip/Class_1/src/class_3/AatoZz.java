package class_3;

import java.util.Scanner;

public class AatoZz {

	public static void main(String[] args) {
		char x;
		for(x='A';x<='Z';x++)
		{
			System.out.println(x);
		}
		System.out.println(" ---------------------------------------------------------------------------------");
		System.out.println(" ---------------------------------------------------------------------------------");
		System.out.println(" ---------------------------------------------------------------------------------");
		for(x='a';x<='z';x++)
		{
			System.out.println(x);
		}
		
	}

}
