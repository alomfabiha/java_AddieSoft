package class_3;

public class Class_3 {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
