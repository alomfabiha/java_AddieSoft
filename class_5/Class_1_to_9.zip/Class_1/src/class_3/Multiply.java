package class_3;

public class Multiply {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
