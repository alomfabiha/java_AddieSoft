package class_3;

import java.util.Scanner;

public class Triangle {

	public static void main(String[] args) {
		float a,b,area;
		Scanner num = new Scanner (System.in);
		
System.out.println(" type base ");
a=num.nextFloat();

System.out.println(" type Height ");
b=num.nextFloat();
area=(a*b)/2f;

System.out.println("Trianguler Area "+area);
	}

}
