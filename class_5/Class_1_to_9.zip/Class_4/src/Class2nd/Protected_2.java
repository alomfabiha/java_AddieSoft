package Class2nd;

import Class_4.M_overLoad_2;

public class Protected_2 extends M_overLoad_2{

	public static void main(String[] args) {
		Protected_2 obj= new Protected_2();
		
	int y=obj.add(2,3);
		
	System.out.println(y);
		

	}

}
