package Class_4;

public class Polimorphism_3  {
		void display(){
			System.out.println("Fabiha");
		}
	}


