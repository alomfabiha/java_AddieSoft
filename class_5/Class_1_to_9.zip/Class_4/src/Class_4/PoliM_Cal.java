package Class_4;

public class PoliM_Cal {

	public static void main(String[] args) {
		
		PoliM_sum	 obj = new PoliM_sum();
		//Poliorphism obj = new Poliorphism();
		
		int sum = obj.addValue(5,2, 30);
		System.out.println(sum);
	}

}
