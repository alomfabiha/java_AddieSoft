package Class_4;

public class Polimorphism_2 {

	public static void main(String[] args) {
	Polimorphism_3 obj = new Polimorphism_3();
	obj.display();

	}

}
