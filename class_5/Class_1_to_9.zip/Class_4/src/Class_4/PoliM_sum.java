package Class_4;



public class PoliM_sum {

 int addValue(int a,int b, int c)
 {
 	return a+b+c;
	
}
}
