package Class_4;

public class Poliorphism {

	public static void main(String[] args) {
		
	Poliorphism obj = new Poliorphism();
	
	int value = obj.addValue(10,20, 30);
	System.out.println(value);
	
    

	}
	
	 int addValue(int a,int b, int c)
	    {
	    	return a+b+c;
		}

}
