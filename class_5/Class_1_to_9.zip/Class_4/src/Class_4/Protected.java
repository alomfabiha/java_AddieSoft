package Class_4;

public class Protected {

	public static void main(String[] args) {
		int a=1;
		int b =3;
		int sum =a+b;
	}

}
