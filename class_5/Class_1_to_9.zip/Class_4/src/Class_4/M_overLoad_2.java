package Class_4;

public class M_overLoad_2 {

	protected void add()
	{
	System.out.println("My name is Fabiha !!!");
	}
	protected int add(int a , int b)
	{
		return a+b;
	}
	
	protected int add(int a , int b, int c)
	{
		return a+b+c;
	}
	
	protected float add(float a , float b, float c, float d)
	{
		return a+b+c+d;
	}
	
}
